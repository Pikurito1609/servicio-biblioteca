package pe.edu.unsaac.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciobibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
