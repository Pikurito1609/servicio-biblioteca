package pe.edu.unsaac.biblioteca.dto;

import pe.edu.unsaac.biblioteca.entidades.Autor;

public class AutorMantenimientoDTO {
	String opcion;
	Autor autor;
	public AutorMantenimientoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AutorMantenimientoDTO(String opcion, Autor autor) {
		super();
		this.opcion = opcion;
		this.autor = autor;
	}
	public String getOpcion() {
		return opcion;
	}
	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}
	public Autor getAutor() {
		return autor;
	}
	public void setAutor(Autor autor) {
		this.autor = autor;
	}	
}
