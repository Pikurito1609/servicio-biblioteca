package pe.edu.unsaac.biblioteca.dto;

/** Lo que la API RECIBE para crear o actualizar un libro (cuerpo JSON). */
public record LibroRequest(String titulo, Integer anio, Double precio,
                           Integer autorId, Integer categoriaId) {
}
