package pe.edu.unsaac.biblioteca.entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CResultado {
	String estado;
	String mensaje;
	@Id
	Integer codigo;

	public CResultado(String estado, String mensaje, Integer codigo) {
		super();
		this.estado = estado;
		this.mensaje = mensaje;
		this.codigo = codigo;
	}
	public CResultado() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
}
