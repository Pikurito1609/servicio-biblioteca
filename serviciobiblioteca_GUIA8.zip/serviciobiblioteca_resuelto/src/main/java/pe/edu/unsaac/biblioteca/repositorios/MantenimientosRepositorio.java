package pe.edu.unsaac.biblioteca.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.unsaac.biblioteca.entidades.CResultado;

@Repository
public interface MantenimientosRepositorio extends JpaRepository<CResultado, Integer> {
	@Query(value="{call sp_mantenimiento_autores(:accion,:pid,:pnombres,:pnacionalidad)}",nativeQuery=true)
	List<CResultado> sp_mantenimiento_autores(@Param("accion") String accion,
											  @Param("pid") Integer pid,
											  @Param("pnombres") String pnombres, 
											  @Param("pnacionalidad") String pnacionalidad);
}
