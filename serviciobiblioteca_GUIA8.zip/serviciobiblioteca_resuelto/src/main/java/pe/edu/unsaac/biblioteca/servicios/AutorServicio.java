package pe.edu.unsaac.biblioteca.servicios;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.unsaac.biblioteca.dto.AutorDTO;
import pe.edu.unsaac.biblioteca.dto.AutorRequest;
import pe.edu.unsaac.biblioteca.dto.LibroDTO;
import pe.edu.unsaac.biblioteca.entidades.Autor;
import pe.edu.unsaac.biblioteca.entidades.Categoria;
import pe.edu.unsaac.biblioteca.excepciones.ConflictoException;
import pe.edu.unsaac.biblioteca.excepciones.NoEncontradoException;
import pe.edu.unsaac.biblioteca.excepciones.ValidacionException;
import pe.edu.unsaac.biblioteca.repositorios.AutorRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.CategoriaRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.LibroRepositorio;

/** Consultas y mantenimiento de los catálogos: autores y categorías. */
@Service
public class AutorServicio {

    private final AutorRepositorio autores;
    private final CategoriaRepositorio categorias;
    private final LibroRepositorio libros;

    public AutorServicio(AutorRepositorio autores, CategoriaRepositorio categorias,
                         LibroRepositorio libros) {
        this.autores = autores;
        this.categorias = categorias;
        this.libros = libros;
    }

    // ===================== CONSULTAS =====================
    @Transactional(readOnly = true)
    public List<AutorDTO> listarAutores() {
        return autores.findAll(Sort.by("nombres")).stream().map(AutorDTO::desde).toList();
    }

    // Usa la relación @OneToMany: autor.getLibros()
    @Transactional(readOnly = true)
    public List<LibroDTO> librosDeAutor(int autorId) {
        return buscarAutor(autorId).getLibros().stream()
                .map(LibroDTO::desde)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<Categoria> listarCategorias() {
        return categorias.findAll(Sort.by("nombre"));
    }

    // ============ CREAR / ACTUALIZAR / ELIMINAR  (Actividad 1) ============
    @Transactional
    public AutorDTO crear(AutorRequest r) {
        validar(r);
        Autor autor = new Autor();
        asignarDatos(autor, r);
        return AutorDTO.desde(autores.save(autor));        // INSERT
    }

    @Transactional
    public AutorDTO actualizar(int id, AutorRequest r) {
        Autor autor = buscarAutor(id);
        validar(r);
        asignarDatos(autor, r);
        return AutorDTO.desde(autores.save(autor));        // UPDATE
    }

    @Transactional
    public void eliminar(int id) {
        Autor autor = buscarAutor(id);
        if (libros.existsByAutorId(id))
            throw new ConflictoException("El autor tiene libros registrados");
        autores.delete(autor);                             // DELETE
    }

    // ===================== AUXILIARES =====================
    private Autor buscarAutor(int id) {
        return autores.findById(id)
                .orElseThrow(() -> new NoEncontradoException("Autor no encontrado"));
    }

    private void validar(AutorRequest r) {
        List<String> errores = new ArrayList<>();
        if (r.nombres() == null || r.nombres().trim().length() < 3)
            errores.add("El nombre debe tener al menos 3 caracteres");
        if (!errores.isEmpty()) throw new ValidacionException(errores);
    }

    private void asignarDatos(Autor autor, AutorRequest r) {
        autor.setNombres(r.nombres().trim());
        // La nacionalidad es opcional: si no llega, queda vacía (default de la tabla)
        autor.setNacionalidad(r.nacionalidad() == null ? "" : r.nacionalidad().trim());
    }
}
