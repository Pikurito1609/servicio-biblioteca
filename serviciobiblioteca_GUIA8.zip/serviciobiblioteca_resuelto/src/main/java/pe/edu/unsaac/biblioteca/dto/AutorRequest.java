package pe.edu.unsaac.biblioteca.dto;

/** Lo que la API RECIBE para crear o actualizar un autor (cuerpo JSON). */
public record AutorRequest(String nombres, String nacionalidad) {
}
