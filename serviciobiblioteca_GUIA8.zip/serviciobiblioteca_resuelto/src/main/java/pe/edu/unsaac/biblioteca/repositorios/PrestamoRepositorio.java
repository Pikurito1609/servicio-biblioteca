package pe.edu.unsaac.biblioteca.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.unsaac.biblioteca.entidades.Prestamo;

public interface PrestamoRepositorio extends JpaRepository<Prestamo, Integer> {

    // Préstamos activos: WHERE fecha_devolucion IS NULL
    List<Prestamo> findByFechaDevolucionIsNullOrderByFechaPrestamo();

    // Historial de un libro, del más reciente al más antiguo
    List<Prestamo> findByLibroIdOrderByFechaPrestamoDesc(Integer libroId);

    // ¿El libro tiene préstamos registrados?
    boolean existsByLibroId(Integer libroId);

    // Actividad 4: historial de un lector, del más reciente al más antiguo
    List<Prestamo> findByLectorIdOrderByFechaPrestamoDesc(Integer lectorId);
}
