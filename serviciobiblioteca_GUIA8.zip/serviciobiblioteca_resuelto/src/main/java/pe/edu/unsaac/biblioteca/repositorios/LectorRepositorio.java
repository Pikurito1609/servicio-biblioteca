package pe.edu.unsaac.biblioteca.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pe.edu.unsaac.biblioteca.entidades.Lector;

/** Actividad 4: repositorio de los lectores. */
@Repository
public interface LectorRepositorio extends JpaRepository<Lector, Integer> {
}
