package pe.edu.unsaac.biblioteca.controladores;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.unsaac.biblioteca.dto.CategoriaRequest;
import pe.edu.unsaac.biblioteca.entidades.Categoria;
import pe.edu.unsaac.biblioteca.servicios.CategoriaServicio;

/**
 * Actividad 2: CRUD de categorías. Los errores (400, 404, 409) los responde
 * ManejadorErrores. Categoría no tiene relaciones que cargar: se puede devolver
 * la entidad.
 */
@RestController
@RequestMapping("/api/categorias")
public class CategoriaController {

    private final CategoriaServicio servicio;

    public CategoriaController(CategoriaServicio servicio) {
        this.servicio = servicio;
    }

    // GET /api/categorias
    @GetMapping
    public List<Categoria> listar() {
        return servicio.listar();
    }

    // POST /api/categorias  -> 201 | 400 | 409
    @PostMapping
    public ResponseEntity<Categoria> crear(@RequestBody CategoriaRequest r) {
        return ResponseEntity.status(201).body(servicio.crear(r));
    }

    // PUT /api/categorias/{id}  -> 200 | 400 | 404 | 409
    @PutMapping("/{id}")
    public Categoria actualizar(@PathVariable int id, @RequestBody CategoriaRequest r) {
        return servicio.actualizar(id, r);
    }

    // DELETE /api/categorias/{id}  -> 204 | 404 | 409 (tiene libros)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
