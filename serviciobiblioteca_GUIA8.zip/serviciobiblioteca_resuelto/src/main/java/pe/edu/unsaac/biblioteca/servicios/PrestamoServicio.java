package pe.edu.unsaac.biblioteca.servicios;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.unsaac.biblioteca.dto.PrestamoDTO;
import pe.edu.unsaac.biblioteca.dto.PrestamoRequest;
import pe.edu.unsaac.biblioteca.entidades.Lector;
import pe.edu.unsaac.biblioteca.entidades.Libro;
import pe.edu.unsaac.biblioteca.entidades.Prestamo;
import pe.edu.unsaac.biblioteca.excepciones.ConflictoException;
import pe.edu.unsaac.biblioteca.excepciones.NoEncontradoException;
import pe.edu.unsaac.biblioteca.excepciones.ValidacionException;
import pe.edu.unsaac.biblioteca.repositorios.LectorRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.LibroRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.PrestamoRepositorio;

@Service
public class PrestamoServicio {

    private final PrestamoRepositorio prestamos;
    private final LibroRepositorio libros;
    private final LectorRepositorio lectores;

    public PrestamoServicio(PrestamoRepositorio prestamos, LibroRepositorio libros,
                            LectorRepositorio lectores) {
        this.prestamos = prestamos;
        this.libros = libros;
        this.lectores = lectores;
    }

    @Transactional(readOnly = true)
    public List<PrestamoDTO> listar(boolean soloActivos) {
        List<Prestamo> lista = soloActivos
                ? prestamos.findByFechaDevolucionIsNullOrderByFechaPrestamo()
                : prestamos.findAll(Sort.by(Sort.Direction.DESC, "fechaPrestamo"));
        return lista.stream().map(PrestamoDTO::desde).toList();
    }

    @Transactional(readOnly = true)
    public List<PrestamoDTO> historialDeLibro(int libroId) {
        if (!libros.existsById(libroId)) throw new NoEncontradoException("Libro no encontrado");
        return prestamos.findByLibroIdOrderByFechaPrestamoDesc(libroId).stream()
                .map(PrestamoDTO::desde).toList();
    }

    // Actividad 4: historial de préstamos de un lector
    @Transactional(readOnly = true)
    public List<PrestamoDTO> historialDeLector(int lectorId) {
        if (!lectores.existsById(lectorId))
            throw new NoEncontradoException("Lector no encontrado");
        return prestamos.findByLectorIdOrderByFechaPrestamoDesc(lectorId).stream()
                .map(PrestamoDTO::desde).toList();
    }

    /**
     * Registra un préstamo. Son DOS cambios: insertar en "prestamo" y marcar
     * el libro como no disponible. @Transactional garantiza que se guarden
     * los dos o ninguno.
     */
    @Transactional
    public PrestamoDTO prestar(PrestamoRequest r) {
        if (r.libroId() == null)
            throw new ValidacionException(List.of("El libroId es obligatorio"));
        if (r.lectorId() == null)
            throw new ValidacionException(List.of("El lectorId es obligatorio"));

        Libro libro = libros.findById(r.libroId())
                .orElseThrow(() -> new NoEncontradoException("Libro no encontrado"));
        if (!libro.isDisponible())
            throw new ConflictoException("El libro ya está prestado");

        Lector lector = lectores.findById(r.lectorId())
                .orElseThrow(() -> new NoEncontradoException("Lector no encontrado"));

        Prestamo prestamo = new Prestamo(libro, lector, LocalDate.now());
        prestamos.save(prestamo);          // INSERT INTO prestamo
        libro.setDisponible(false);        // UPDATE libro (automático al terminar)
        return PrestamoDTO.desde(prestamo);
    }

    /** Registra la devolución: fecha de devolución + libro disponible otra vez. */
    @Transactional
    public PrestamoDTO devolver(int prestamoId) {
        Prestamo prestamo = prestamos.findById(prestamoId)
                .orElseThrow(() -> new NoEncontradoException("Préstamo no encontrado"));
        if (!prestamo.isActivo())
            throw new ConflictoException("El préstamo ya fue devuelto");

        prestamo.setFechaDevolucion(LocalDate.now());
        prestamo.getLibro().setDisponible(true);
        return PrestamoDTO.desde(prestamo);
    }
}
