package pe.edu.unsaac.biblioteca.excepciones;

/** Regla de negocio que impide la operación: se convierte en 409. */
public class ConflictoException extends RuntimeException {
    public ConflictoException(String mensaje) {
        super(mensaje);
    }
}
