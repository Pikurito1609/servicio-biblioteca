package pe.edu.unsaac.biblioteca.dto;

/** Lo que la API RECIBE para crear o actualizar una categoría (Actividad 2). */
public record CategoriaRequest(String nombre) {
}
