package pe.edu.unsaac.biblioteca.repositorios;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pe.edu.unsaac.biblioteca.entidades.Categoria;

// JpaRepository<Entidad, TipoDelId> ya trae: findAll, findById, save, deleteById, count...
@Repository
public interface CategoriaRepositorio extends JpaRepository<Categoria, Integer> {

    // Actividad 2: SELECT ... FROM categoria WHERE LOWER(nombre) = LOWER(?)
    Optional<Categoria> findByNombreIgnoreCase(String nombre);
}
