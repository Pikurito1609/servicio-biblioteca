package pe.edu.unsaac.biblioteca.controladores;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.unsaac.biblioteca.dto.PrestamoDTO;
import pe.edu.unsaac.biblioteca.dto.PrestamoRequest;
import pe.edu.unsaac.biblioteca.servicios.PrestamoServicio;

@RestController
@RequestMapping("/api/prestamos")
public class PrestamoController {

    private final PrestamoServicio servicio;

    public PrestamoController(PrestamoServicio servicio) {
        this.servicio = servicio;
    }

    // GET /api/prestamos  o  /api/prestamos?activos=true
    @GetMapping
    public List<PrestamoDTO> listar(@RequestParam(defaultValue = "false") boolean activos) {
        return servicio.listar(activos);
    }

    // POST /api/prestamos   { "libroId": 2, "lectorId": 4 }
    @PostMapping
    public ResponseEntity<PrestamoDTO> prestar(@RequestBody PrestamoRequest r) {
        return ResponseEntity.status(201).body(servicio.prestar(r));
    }

    // PUT /api/prestamos/5/devolucion
    @PutMapping("/{id}/devolucion")
    public PrestamoDTO devolver(@PathVariable int id) {
        return servicio.devolver(id);
    }
}
