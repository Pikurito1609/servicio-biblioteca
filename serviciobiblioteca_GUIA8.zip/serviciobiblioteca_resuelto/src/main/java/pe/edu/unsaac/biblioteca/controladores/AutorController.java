package pe.edu.unsaac.biblioteca.controladores;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.unsaac.biblioteca.dto.AutorDTO;
import pe.edu.unsaac.biblioteca.dto.AutorRequest;
import pe.edu.unsaac.biblioteca.dto.LibroDTO;
import pe.edu.unsaac.biblioteca.servicios.AutorServicio;

/** Los errores (404, 400, 409) los responde ManejadorErrores. */
@RestController
@RequestMapping("/api")
public class AutorController {

    private final AutorServicio servicio;

    public AutorController(AutorServicio servicio) {
        this.servicio = servicio;
    }

    // GET /api/autores
    @GetMapping("/autores")
    public List<AutorDTO> autores() {
        return servicio.listarAutores();
    }

    // GET /api/autores/4/libros
    @GetMapping("/autores/{id}/libros")
    public List<LibroDTO> librosDeAutor(@PathVariable int id) {
        return servicio.librosDeAutor(id);
    }

    // POST /api/autores  -> 201 | 400 | (409 no aplica: el nombre no es único)
    @PostMapping("/autores")
    public ResponseEntity<AutorDTO> crear(@RequestBody AutorRequest r) {
        return ResponseEntity.status(201).body(servicio.crear(r));
    }

    // PUT /api/autores/{id}  -> 200 | 400 | 404
    @PutMapping("/autores/{id}")
    public AutorDTO actualizar(@PathVariable int id, @RequestBody AutorRequest r) {
        return servicio.actualizar(id, r);
    }

    // DELETE /api/autores/{id}  -> 204 | 404 | 409 (tiene libros)
    @DeleteMapping("/autores/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
