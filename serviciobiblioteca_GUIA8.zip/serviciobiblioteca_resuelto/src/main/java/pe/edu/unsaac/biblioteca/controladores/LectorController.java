package pe.edu.unsaac.biblioteca.controladores;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.unsaac.biblioteca.dto.PrestamoDTO;
import pe.edu.unsaac.biblioteca.servicios.PrestamoServicio;

/** Actividad 4: consultas de lectores. Los errores los responde ManejadorErrores. */
@RestController
@RequestMapping("/api/lectores")
public class LectorController {

    private final PrestamoServicio servicio;

    public LectorController(PrestamoServicio servicio) {
        this.servicio = servicio;
    }

    // GET /api/lectores/5/prestamos  (historial de préstamos de un lector)
    @GetMapping("/{id}/prestamos")
    public List<PrestamoDTO> historial(@PathVariable int id) {
        return servicio.historialDeLector(id);
    }
}
