package pe.edu.unsaac.biblioteca.servicios;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.unsaac.biblioteca.dto.CategoriaResumenDTO;
import pe.edu.unsaac.biblioteca.dto.LibroDTO;
import pe.edu.unsaac.biblioteca.dto.LibroMasPrestadoDTO;
import pe.edu.unsaac.biblioteca.dto.LibroRequest;
import pe.edu.unsaac.biblioteca.entidades.Libro;
import pe.edu.unsaac.biblioteca.excepciones.ConflictoException;
import pe.edu.unsaac.biblioteca.excepciones.NoEncontradoException;
import pe.edu.unsaac.biblioteca.excepciones.ValidacionException;
import pe.edu.unsaac.biblioteca.repositorios.AutorRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.CategoriaRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.LibroRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.PrestamoRepositorio;

@Service
public class LibroServicio {

    private final LibroRepositorio libros;
    private final AutorRepositorio autores;
    private final CategoriaRepositorio categorias;
    private final PrestamoRepositorio prestamos;

    public LibroServicio(LibroRepositorio libros, AutorRepositorio autores,
                         CategoriaRepositorio categorias, PrestamoRepositorio prestamos) {
        this.libros = libros;
        this.autores = autores;
        this.categorias = categorias;
        this.prestamos = prestamos;
    }

    // ===================== CONSULTAS =====================
    // readOnly: transacción de solo lectura; permite usar las relaciones LAZY
    @Transactional(readOnly = true)
    public List<LibroDTO> listar(String texto, String categoria) {
        String t = texto == null ? "" : texto.trim();
        String c = categoria == null ? "" : categoria.trim();

        List<Libro> resultado;
        if (!t.isEmpty()) {
            resultado = libros.buscar(t);
        } else if (!c.isEmpty()) {
            resultado = libros.findByCategoriaNombreIgnoreCase(c);
        } else {
            resultado = libros.findAll(Sort.by("id"));
        }
        return resultado.stream()
                .filter(l -> c.isEmpty() || l.getCategoria().getNombre().equalsIgnoreCase(c))
                .map(LibroDTO::desde)
                .toList();
    }

    @Transactional(readOnly = true)
    public LibroDTO obtener(int id) {
        return LibroDTO.desde(buscarLibro(id));
    }

    @Transactional(readOnly = true)
    public List<CategoriaResumenDTO> resumenPorCategoria() {
        return libros.resumenPorCategoria();
    }

    @Transactional(readOnly = true)
    public List<LibroDTO> masCaros(int cantidad) {
        return libros.masCaros(cantidad).stream().map(LibroDTO::desde).toList();
    }

    // Actividad 3a: libros publicados en un rango de años (consulta derivada)
    @Transactional(readOnly = true)
    public List<LibroDTO> listarPorRango(int desde, int hasta) {
        if (desde > hasta) {          // si el rango viene invertido, se ordena
            int aux = desde;
            desde = hasta;
            hasta = aux;
        }
        return libros.findByAnioBetweenOrderByAnio(desde, hasta).stream()
                .map(LibroDTO::desde).toList();
    }

    // Actividad 3b: los libros más prestados (JPQL con JOIN y GROUP BY)
    @Transactional(readOnly = true)
    public List<LibroMasPrestadoDTO> masPrestados() {
        return libros.masPrestados();
    }

    // ===================== CREAR / ACTUALIZAR / ELIMINAR =====================
    @Transactional
    public LibroDTO crear(LibroRequest r) {
        validar(r, null);
        Libro libro = new Libro();
        asignarDatos(libro, r);
        return LibroDTO.desde(libros.save(libro));     // INSERT
    }

    @Transactional
    public LibroDTO actualizar(int id, LibroRequest r) {
        Libro libro = buscarLibro(id);
        validar(r, id);
        asignarDatos(libro, r);
        // Dentro de @Transactional, JPA detecta los cambios y hace el UPDATE
        // al terminar el método; save() es opcional.
        return LibroDTO.desde(libros.save(libro));
    }

    @Transactional
    public void eliminar(int id) {
        Libro libro = buscarLibro(id);
        if (!libro.isDisponible())
            throw new ConflictoException("No se puede eliminar un libro prestado");
        if (prestamos.existsByLibroId(id))
            throw new ConflictoException("El libro tiene préstamos registrados");
        libros.delete(libro);                          // DELETE
    }

    // ===================== AUXILIARES =====================
    private Libro buscarLibro(int id) {
        return libros.findById(id)
                .orElseThrow(() -> new NoEncontradoException("Libro no encontrado"));
    }

    private void validar(LibroRequest r, Integer idActual) {
        List<String> errores = new ArrayList<>();
        if (r.titulo() == null || r.titulo().trim().length() < 3)
            errores.add("El título debe tener al menos 3 caracteres");
        if (r.anio() == null || r.anio() < 1450 || r.anio() > 2030)
            errores.add("El año no es válido");
        if (r.precio() == null || r.precio() <= 0)
            errores.add("El precio debe ser mayor que 0");
        if (r.autorId() == null || !autores.existsById(r.autorId()))
            errores.add("El autor no existe");
        if (r.categoriaId() == null || !categorias.existsById(r.categoriaId()))
            errores.add("La categoría no existe");

        if (errores.isEmpty()) {                       // título repetido para el mismo autor
            libros.findByTituloIgnoreCaseAndAutorId(r.titulo().trim(), r.autorId())
                  .filter(otro -> !otro.getId().equals(idActual))
                  .ifPresent(otro -> errores.add("Ese autor ya tiene un libro con ese título"));
        }
        if (!errores.isEmpty()) throw new ValidacionException(errores);
    }

    private void asignarDatos(Libro libro, LibroRequest r) {
        libro.setTitulo(r.titulo().trim());
        libro.setAnio(r.anio());
        libro.setPrecio(r.precio());
        libro.setAutor(autores.findById(r.autorId()).orElseThrow());
        libro.setCategoria(categorias.findById(r.categoriaId()).orElseThrow());
    }
}
