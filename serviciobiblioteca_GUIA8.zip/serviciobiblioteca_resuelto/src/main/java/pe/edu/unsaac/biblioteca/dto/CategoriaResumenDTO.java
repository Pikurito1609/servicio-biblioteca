package pe.edu.unsaac.biblioteca.dto;

/** Resultado de la consulta JPQL resumenPorCategoria(). */
public record CategoriaResumenDTO(String categoria, Long cantidad, Double precioPromedio) {
}
