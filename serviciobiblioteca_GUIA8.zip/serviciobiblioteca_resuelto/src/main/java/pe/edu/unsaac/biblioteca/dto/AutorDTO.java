package pe.edu.unsaac.biblioteca.dto;

import pe.edu.unsaac.biblioteca.entidades.Autor;

public record AutorDTO(Integer id, String nombres, String nacionalidad, int cantidadLibros) {

    public static AutorDTO desde(Autor a) {
        return new AutorDTO(a.getId(), a.getNombres(), a.getNacionalidad(),
                a.getLibros().size());          // usa la relación @OneToMany
    }
}
