package pe.edu.unsaac.biblioteca.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity                       // esta clase representa una tabla
@Table(name = "categoria")    // nombre de la tabla en MySQL
public class Categoria {

    @Id                                                   // clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY)   // AUTO_INCREMENT
    private Integer id;

    @Column(nullable = false, unique = true, length = 60)
    private String nombre;

    public Categoria() { }   // obligatorio para JPA

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
}
