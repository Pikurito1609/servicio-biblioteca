package pe.edu.unsaac.biblioteca.servicios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.unsaac.biblioteca.entidades.Autor;
import pe.edu.unsaac.biblioteca.entidades.CResultado;
import pe.edu.unsaac.biblioteca.repositorios.MantenimientosRepositorio;

@Service
public class MantenimientoServicio {
	@Autowired
	MantenimientosRepositorio repositorio;
	
	public CResultado mantenimientoAutores(String accion, Autor autor) {
		if(autor.getNombres()==null || autor.getNombres().isBlank())
			return new CResultado("ERROR","No ingreso nombres",-1);
		
		if(autor.getNacionalidad()==null || autor.getNacionalidad().isBlank())
			return new CResultado("ERROR","No ingreso la nacionalidad",-1);
	
		return repositorio.sp_mantenimiento_autores(accion, 
													autor.getId(),
													autor.getNombres(),
													autor.getNacionalidad()).get(0);
	}	
}
