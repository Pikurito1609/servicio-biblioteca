package pe.edu.unsaac.biblioteca.dto;

/** Actividad 3: resultado de la consulta JPQL masPrestados(). */
public record LibroMasPrestadoDTO(String titulo, Long vecesPrestado) {
}
