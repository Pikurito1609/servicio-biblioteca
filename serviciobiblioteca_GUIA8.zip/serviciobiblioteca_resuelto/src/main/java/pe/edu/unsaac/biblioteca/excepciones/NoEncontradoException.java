package pe.edu.unsaac.biblioteca.excepciones;

/** Se convierte en una respuesta 404. */
public class NoEncontradoException extends RuntimeException {
    public NoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
