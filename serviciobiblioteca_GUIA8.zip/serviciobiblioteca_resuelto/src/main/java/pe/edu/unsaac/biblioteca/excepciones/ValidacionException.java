package pe.edu.unsaac.biblioteca.excepciones;

import java.util.List;

/** Datos inválidos: se convierte en 400 con la lista de errores. */
public class ValidacionException extends RuntimeException {

    private final List<String> errores;

    public ValidacionException(List<String> errores) {
        super(String.join(", ", errores));
        this.errores = errores;
    }

    public List<String> getErrores() {
        return errores;
    }
}
