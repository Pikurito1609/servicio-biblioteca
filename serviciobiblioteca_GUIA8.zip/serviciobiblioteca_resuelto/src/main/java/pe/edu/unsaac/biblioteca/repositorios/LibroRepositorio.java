package pe.edu.unsaac.biblioteca.repositorios;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import pe.edu.unsaac.biblioteca.dto.CategoriaResumenDTO;
import pe.edu.unsaac.biblioteca.dto.LibroMasPrestadoDTO;
import pe.edu.unsaac.biblioteca.entidades.Libro;

public interface LibroRepositorio extends JpaRepository<Libro, Integer> {

    // ===== 1. Consultas DERIVADAS: Spring genera el SQL a partir del nombre =====
    // SELECT ... FROM libro l JOIN categoria c ... WHERE LOWER(c.nombre) = LOWER(?)
    List<Libro> findByCategoriaNombreIgnoreCase(String categoria);

    // SELECT ... FROM libro WHERE autor_id = ?
    List<Libro> findByAutorId(Integer autorId);

    // SELECT ... FROM libro WHERE LOWER(titulo) = LOWER(?) AND autor_id = ?
    Optional<Libro> findByTituloIgnoreCaseAndAutorId(String titulo, Integer autorId);

    // ¿La categoría tiene libros registrados? (Actividad 2)
    boolean existsByCategoriaId(Integer categoriaId);

    // ¿El autor tiene libros registrados? (Actividad 1)
    boolean existsByAutorId(Integer autorId);

    // Actividad 3a: SELECT ... FROM libro WHERE anio BETWEEN ? AND ? ORDER BY anio
    List<Libro> findByAnioBetweenOrderByAnio(int desde, int hasta);

    // ===== 2. Consultas JPQL con @Query: se escriben sobre ENTIDADES, no tablas =====
    @Query("""
           SELECT l FROM Libro l
           WHERE LOWER(l.titulo) LIKE LOWER(CONCAT('%', :texto, '%'))
              OR LOWER(l.autor.nombres) LIKE LOWER(CONCAT('%', :texto, '%'))
           ORDER BY l.id
           """)
    List<Libro> buscar(@Param("texto") String texto);

    // JPQL con JOIN, GROUP BY y resultado en un DTO
    @Query("""
           SELECT new pe.edu.unsaac.biblioteca.dto.CategoriaResumenDTO(
                      c.nombre, COUNT(l), AVG(l.precio))
           FROM Libro l JOIN l.categoria c
           GROUP BY c.nombre
           ORDER BY c.nombre
           """)
    List<CategoriaResumenDTO> resumenPorCategoria();

    // Actividad 3b: los libros más prestados, con JOIN, GROUP BY y DTO
    // "vecesPrestado" cuenta los préstamos de cada libro (activos y devueltos)
    @Query("""
           SELECT new pe.edu.unsaac.biblioteca.dto.LibroMasPrestadoDTO(
                      l.titulo, COUNT(p))
           FROM Prestamo p JOIN p.libro l
           GROUP BY l.id, l.titulo
           ORDER BY COUNT(p) DESC
           """)
    List<LibroMasPrestadoDTO> masPrestados();

    // ===== 3. Consulta NATIVA: SQL de MySQL tal cual =====
    @Query(value = "SELECT * FROM libro ORDER BY precio DESC LIMIT :cantidad",
           nativeQuery = true)
    List<Libro> masCaros(@Param("cantidad") int cantidad);
}
