package pe.edu.unsaac.biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiciobibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiciobibliotecaApplication.class, args);
	}

}
