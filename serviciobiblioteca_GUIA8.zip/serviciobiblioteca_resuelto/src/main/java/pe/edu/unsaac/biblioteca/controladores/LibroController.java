package pe.edu.unsaac.biblioteca.controladores;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.unsaac.biblioteca.dto.CategoriaResumenDTO;
import pe.edu.unsaac.biblioteca.dto.LibroDTO;
import pe.edu.unsaac.biblioteca.dto.LibroMasPrestadoDTO;
import pe.edu.unsaac.biblioteca.dto.LibroRequest;
import pe.edu.unsaac.biblioteca.dto.PrestamoDTO;
import pe.edu.unsaac.biblioteca.servicios.LibroServicio;
import pe.edu.unsaac.biblioteca.servicios.PrestamoServicio;

/** Los errores (404, 400, 409) los responde ManejadorErrores. */
@RestController
@RequestMapping("/api/libros")
public class LibroController {

    private final LibroServicio servicio;
    private final PrestamoServicio prestamoServicio;

    public LibroController(LibroServicio servicio, PrestamoServicio prestamoServicio) {
        this.servicio = servicio;
        this.prestamoServicio = prestamoServicio;
    }

    // GET /api/libros  o  ?q=java  o  ?categoria=Redes
    @GetMapping
    public List<LibroDTO> listar(@RequestParam(required = false) String q,
                                 @RequestParam(required = false) String categoria) {
        return servicio.listar(q, categoria);
    }

    @GetMapping("/{id}")
    public LibroDTO obtener(@PathVariable int id) {
        return servicio.obtener(id);
    }

    // GET /api/libros/resumen  (JPQL con GROUP BY)
    @GetMapping("/resumen")
    public List<CategoriaResumenDTO> resumen() {
        return servicio.resumenPorCategoria();
    }

    // GET /api/libros/mas-caros?cantidad=3  (consulta nativa)
    @GetMapping("/mas-caros")
    public List<LibroDTO> masCaros(@RequestParam(defaultValue = "5") int cantidad) {
        return servicio.masCaros(cantidad);
    }

    // GET /api/libros/rango?desde=2010&hasta=2020  (consulta derivada, Actividad 3)
    @GetMapping("/rango")
    public List<LibroDTO> rango(@RequestParam(defaultValue = "1450") int desde,
                                @RequestParam(defaultValue = "2100") int hasta) {
        return servicio.listarPorRango(desde, hasta);
    }

    // GET /api/libros/mas-prestados  (JPQL con JOIN y GROUP BY, Actividad 3)
    @GetMapping("/mas-prestados")
    public List<LibroMasPrestadoDTO> masPrestados() {
        return servicio.masPrestados();
    }

    // GET /api/libros/7/prestamos  (historial)
    @GetMapping("/{id}/prestamos")
    public List<PrestamoDTO> historial(@PathVariable int id) {
        return prestamoServicio.historialDeLibro(id);
    }

    @PostMapping
    public ResponseEntity<LibroDTO> crear(@RequestBody LibroRequest r) {
        return ResponseEntity.status(201).body(servicio.crear(r));
    }

    @PutMapping("/{id}")
    public LibroDTO actualizar(@PathVariable int id, @RequestBody LibroRequest r) {
        return servicio.actualizar(id, r);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
