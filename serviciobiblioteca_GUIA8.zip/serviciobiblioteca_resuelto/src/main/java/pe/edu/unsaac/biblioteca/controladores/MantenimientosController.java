package pe.edu.unsaac.biblioteca.controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import pe.edu.unsaac.biblioteca.dto.AutorMantenimientoDTO;
import pe.edu.unsaac.biblioteca.entidades.CResultado;
import pe.edu.unsaac.biblioteca.servicios.MantenimientoServicio;

@RestController
@RequestMapping("/api/mantenimiento")
public class MantenimientosController {
	@Autowired
	private MantenimientoServicio servicio;
	
	@PostMapping(value="/autores",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CResultado> mantenimientoAutores(@RequestBody AutorMantenimientoDTO autor) {
		return ResponseEntity.ok(servicio.mantenimientoAutores(autor.getOpcion(), autor.getAutor()));
	}
}
