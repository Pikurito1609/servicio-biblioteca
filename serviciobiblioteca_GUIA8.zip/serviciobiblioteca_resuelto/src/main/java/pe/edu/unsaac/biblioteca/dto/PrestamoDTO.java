package pe.edu.unsaac.biblioteca.dto;

import java.time.LocalDate;

import pe.edu.unsaac.biblioteca.entidades.Prestamo;

public record PrestamoDTO(Integer id, Integer libroId, String libro,
                          Integer lectorId, String lector,
                          LocalDate fechaPrestamo, LocalDate fechaDevolucion,
                          boolean activo) {

    public static PrestamoDTO desde(Prestamo p) {
        return new PrestamoDTO(p.getId(), p.getLibro().getId(), p.getLibro().getTitulo(),
                p.getLector().getId(), p.getLector().getNombres(),
                p.getFechaPrestamo(), p.getFechaDevolucion(), p.isActivo());
    }
}
