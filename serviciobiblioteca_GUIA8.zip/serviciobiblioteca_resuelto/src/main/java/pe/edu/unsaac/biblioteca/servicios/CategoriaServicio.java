package pe.edu.unsaac.biblioteca.servicios;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.unsaac.biblioteca.dto.CategoriaRequest;
import pe.edu.unsaac.biblioteca.entidades.Categoria;
import pe.edu.unsaac.biblioteca.excepciones.ConflictoException;
import pe.edu.unsaac.biblioteca.excepciones.NoEncontradoException;
import pe.edu.unsaac.biblioteca.excepciones.ValidacionException;
import pe.edu.unsaac.biblioteca.repositorios.CategoriaRepositorio;
import pe.edu.unsaac.biblioteca.repositorios.LibroRepositorio;

/** Actividad 2: mantenimiento del catálogo de categorías. */
@Service
public class CategoriaServicio {

    private final CategoriaRepositorio categorias;
    private final LibroRepositorio libros;

    public CategoriaServicio(CategoriaRepositorio categorias, LibroRepositorio libros) {
        this.categorias = categorias;
        this.libros = libros;
    }

    @Transactional(readOnly = true)
    public List<Categoria> listar() {
        return categorias.findAll(Sort.by("nombre"));
    }

    @Transactional
    public Categoria crear(CategoriaRequest r) {
        validar(r, null);
        Categoria categoria = new Categoria();
        categoria.setNombre(r.nombre().trim());
        return categorias.save(categoria);                 // INSERT
    }

    @Transactional
    public Categoria actualizar(int id, CategoriaRequest r) {
        Categoria categoria = buscarCategoria(id);
        validar(r, id);
        categoria.setNombre(r.nombre().trim());            // UPDATE automático
        return categorias.save(categoria);
    }

    @Transactional
    public void eliminar(int id) {
        Categoria categoria = buscarCategoria(id);
        if (libros.existsByCategoriaId(id))
            throw new ConflictoException("La categoría tiene libros registrados");
        categorias.delete(categoria);                      // DELETE
    }

    // ===================== AUXILIARES =====================
    private Categoria buscarCategoria(int id) {
        return categorias.findById(id)
                .orElseThrow(() -> new NoEncontradoException("Categoría no encontrada"));
    }

    private void validar(CategoriaRequest r, Integer idActual) {
        List<String> errores = new ArrayList<>();
        if (r.nombre() == null || r.nombre().trim().length() < 3)
            errores.add("El nombre debe tener al menos 3 caracteres");
        if (!errores.isEmpty()) throw new ValidacionException(errores);

        // Regla 409: no se repite el nombre (ignora mayúsculas/minúsculas).
        // La consulta derivada findByNombreIgnoreCase está en CategoriaRepositorio.
        categorias.findByNombreIgnoreCase(r.nombre().trim())
                  .filter(otra -> !otra.getId().equals(idActual))
                  .ifPresent(otra -> {
                      throw new ConflictoException("Ya existe una categoría con ese nombre");
                  });
    }
}
