package pe.edu.unsaac.biblioteca.dto;

import pe.edu.unsaac.biblioteca.entidades.Libro;

/** Lo que la API DEVUELVE de un libro (respuesta JSON). */
public record LibroDTO(Integer id, String titulo, int anio, double precio,
                       boolean disponible, Integer autorId, String autor,
                       Integer categoriaId, String categoria) {

    public static LibroDTO desde(Libro l) {
        return new LibroDTO(l.getId(), l.getTitulo(), l.getAnio(), l.getPrecio(),
                l.isDisponible(),
                l.getAutor().getId(), l.getAutor().getNombres(),
                l.getCategoria().getId(), l.getCategoria().getNombre());
    }
}
