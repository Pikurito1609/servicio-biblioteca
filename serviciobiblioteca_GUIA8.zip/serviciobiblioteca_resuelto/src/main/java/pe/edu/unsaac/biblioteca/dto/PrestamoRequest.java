package pe.edu.unsaac.biblioteca.dto;

/** Actividad 4: la API recibe el id del lector, no su nombre. */
public record PrestamoRequest(Integer libroId, Integer lectorId) {
}
