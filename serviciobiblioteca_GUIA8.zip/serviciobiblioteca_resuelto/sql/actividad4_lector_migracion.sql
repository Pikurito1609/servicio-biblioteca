-- ============================================================
-- Actividad 4: normalización de los préstamos (MySQL 8)
-- La columna de texto prestamo.lector pasa a ser una tabla propia:
--   1) crea la tabla lector (id, nombres, dni único, correo)
--   2) la llena con los lectores ya registrados en prestamo.lector
--   3) crea la FK lector_id, migra los datos y elimina la columna lector
-- Ejecutar en MySQL Workbench con la base bdbiblioteca ya cargada
-- (bdbiblioteca20261119.sql).
-- ============================================================
USE bdbiblioteca;

-- 1. La nueva tabla de lectores
CREATE TABLE lector (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    dni     CHAR(8)      NOT NULL UNIQUE,
    correo  VARCHAR(100) NOT NULL
);

-- 2. Los lectores nuevos salen de los nombres que ya estaban en prestamo.
--    dni provisional: 80 + numero de orden (se puede corregir a mano despues);
--    correo provisional: nombre@biblioteca.edu.pe, sin tildes ni espacios.
INSERT INTO lector (nombres, dni, correo)
SELECT t.lector,
       CONCAT('80', LPAD(ROW_NUMBER() OVER (ORDER BY t.lector), 6, '0')),
       CONCAT(
           REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
               LOWER(REPLACE(t.lector, ' ', '.')),
           'á','a'), 'é','e'), 'í','i'), 'ó','o'), 'ú','u'), 'ñ','n'),
       '@biblioteca.edu.pe')
FROM (SELECT DISTINCT lector FROM prestamo) AS t;

-- 3. Vincular cada préstamo con su lector y dejar la FK obligatoria
ALTER TABLE prestamo ADD COLUMN lector_id INT NULL AFTER libro_id;
UPDATE prestamo
SET lector_id = (SELECT l.id FROM lector l WHERE l.nombres = prestamo.lector);
ALTER TABLE prestamo MODIFY lector_id INT NOT NULL;
ALTER TABLE prestamo
    ADD CONSTRAINT fk_prestamo_lector FOREIGN KEY (lector_id) REFERENCES lector(id);
ALTER TABLE prestamo DROP COLUMN lector;

-- 4. Verificación: cada préstamo con su lector y su libro
SELECT p.id, l.nombres AS lector, l.dni, l.correo,
       lb.titulo AS libro, p.fecha_prestamo, p.fecha_devolucion
FROM prestamo p
JOIN lector l ON l.id = p.lector_id
JOIN libro lb ON lb.id = p.libro_id
ORDER BY p.id;
