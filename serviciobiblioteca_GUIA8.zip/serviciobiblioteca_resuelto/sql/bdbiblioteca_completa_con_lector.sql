-- ============================================================
-- BASE DE DATOS: bdbiblioteca  (MySQL 8)
-- Guía 8: Spring Data JPA - entidades y relaciones entre tablas
-- Versión NORMALIZADA (Actividad 4): la tabla lector reemplaza a la
-- columna de texto prestamo.lector; cada préstamo apunta a su lector
-- con la FK lector_id.
-- ============================================================

DROP DATABASE IF EXISTS bdbiblioteca;
CREATE DATABASE bdbiblioteca CHARACTER SET utf8mb4;
USE bdbiblioteca;

CREATE TABLE autor (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    nombres      VARCHAR(100) NOT NULL,
    nacionalidad VARCHAR(60)  NOT NULL DEFAULT ''
);

CREATE TABLE categoria (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL UNIQUE
);

-- Actividad 4: los lectores ahora son una tabla propia
CREATE TABLE lector (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    dni     CHAR(8)      NOT NULL UNIQUE,
    correo  VARCHAR(100) NOT NULL
);

CREATE TABLE libro (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    titulo      VARCHAR(150) NOT NULL,
    anio        INT          NOT NULL,
    precio      DECIMAL(8,2) NOT NULL,
    disponible  BOOLEAN      NOT NULL DEFAULT TRUE,
    autor_id    INT          NOT NULL,
    categoria_id INT         NOT NULL,
    CONSTRAINT fk_libro_autor     FOREIGN KEY (autor_id)     REFERENCES autor(id),
    CONSTRAINT fk_libro_categoria FOREIGN KEY (categoria_id) REFERENCES categoria(id),
    CONSTRAINT uq_libro_titulo_autor UNIQUE (titulo, autor_id)
);

CREATE TABLE prestamo (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    libro_id        INT  NOT NULL,
    lector_id       INT  NOT NULL,
    fecha_prestamo  DATE NOT NULL,
    fecha_devolucion DATE NULL,
    CONSTRAINT fk_prestamo_libro  FOREIGN KEY (libro_id)  REFERENCES libro(id),
    CONSTRAINT fk_prestamo_lector FOREIGN KEY (lector_id) REFERENCES lector(id)
);

INSERT INTO autor (id, nombres, nacionalidad) VALUES
  (1, 'Ana Torres', 'Peruana'),
  (2, 'Luis Mamani', 'Peruana'),
  (3, 'Carla Quispe', 'Peruana'),
  (4, 'Jorge Huamán', 'Peruana'),
  (5, 'Rosa Condori', 'Peruana'),
  (6, 'Pedro Salas', 'Peruana'),
  (7, 'Lucía Vargas', 'Peruana'),
  (8, 'Miguel Ccahuana', 'Peruana'),
  (9, 'FEDERICO GARCIA LORCA', 'ESPAÑOL');

INSERT INTO categoria (id, nombre) VALUES
  (1, 'Algoritmos'),
  (2, 'Bases de Datos'),
  (3, 'Desarrollo Web'),
  (4, 'Inteligencia Artificial'),
  (5, 'Java'),
  (6, 'Redes'),
  (7, 'Sistemas Operativos');

INSERT INTO lector (id, nombres, dni, correo) VALUES
  (1, 'Diego Flores', '80000001', 'diego.flores@biblioteca.edu.pe'),
  (2, 'Elena Cusi', '80000002', 'elena.cusi@biblioteca.edu.pe'),
  (3, 'José Ramos', '80000003', 'jose.ramos@biblioteca.edu.pe'),
  (4, 'María López', '80000004', 'maria.lopez@biblioteca.edu.pe'),
  (5, 'Raúl Ttito', '80000005', 'raul.ttito@biblioteca.edu.pe'),
  (6, 'Sofía Apaza', '80000006', 'sofia.apaza@biblioteca.edu.pe');

INSERT INTO libro (id, titulo, anio, precio, disponible, autor_id, categoria_id) VALUES
  (1, 'Guía práctica de Bases de Datos', 2012, 67.05, 1, 6, 2),
  (2, 'Aprende Algoritmos', 2000, 84.15, 1, 1, 1),
  (3, 'Manual de Bases de Datos', 2008, 123.95, 1, 4, 2),
  (4, 'Fundamentos de Bases de Datos', 2025, 141.68, 1, 4, 2),
  (5, 'Fundamentos de Inteligencia Artificial', 2010, 55.17, 1, 5, 4),
  (6, 'Manual de Inteligencia Artificial', 2015, 62.90, 1, 2, 4),
  (7, 'Manual de Java', 2002, 120.30, 0, 5, 5),
  (8, 'Guía práctica de Algoritmos', 2016, 31.33, 1, 2, 1),
  (9, 'Aprende Java', 2001, 87.67, 1, 6, 5),
  (10, 'Aprende Redes', 2020, 52.65, 1, 5, 6),
  (11, 'Fundamentos de Algoritmos', 2013, 82.16, 1, 3, 1),
  (12, 'Introducción a Java', 2014, 95.87, 0, 8, 5),
  (13, 'Guía práctica de Algoritmos', 2016, 85.24, 1, 7, 1),
  (14, 'Guía práctica de Sistemas Operativos', 2001, 145.50, 1, 3, 7),
  (15, 'Guía práctica de Bases de Datos', 2020, 105.94, 1, 4, 2),
  (16, 'Aprende Inteligencia Artificial', 2021, 71.21, 1, 1, 4),
  (17, 'Fundamentos de Bases de Datos', 2022, 103.95, 1, 7, 2),
  (18, 'Fundamentos de Redes', 2010, 64.99, 0, 2, 6),
  (19, 'Guía práctica de Java', 2016, 85.61, 1, 6, 5),
  (20, 'Manual de Sistemas Operativos', 2023, 113.29, 0, 7, 7);

INSERT INTO prestamo (id, libro_id, lector_id, fecha_prestamo, fecha_devolucion) VALUES
  (1, 7, 4, '2026-11-10', NULL),
  (2, 12, 3, '2026-11-11', NULL),
  (3, 18, 2, '2026-11-12', NULL),
  (4, 20, 5, '2026-11-13', NULL),
  (5, 1, 2, '2026-10-01', '2026-10-08'),
  (6, 3, 5, '2026-10-05', '2026-10-12'),
  (7, 5, 6, '2026-10-10', '2026-10-20'),
  (8, 1, 1, '2026-10-15', '2026-10-22'),
  (9, 8, 4, '2026-10-20', '2026-10-27'),
  (10, 3, 3, '2026-11-01', '2026-11-06');

-- Procedimiento del módulo de mantenimientos (Guía 7)
DELIMITER ;;
DROP PROCEDURE IF EXISTS `sp_mantenimiento_autores`;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_mantenimiento_autores`(
    IN accion VARCHAR(10),
    IN pid INT,
    IN pnombres VARCHAR(100),
    IN pnacionalidad VARCHAR(60)
)
BEGIN
    DECLARE estado VARCHAR(10);
    DECLARE mensaje VARCHAR(255);
    DECLARE codigo INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET estado = 'ERROR';
        SET mensaje = 'Ocurrió un error durante la operación';
        SET codigo = -1;
        SELECT estado, mensaje, codigo;
    END;

    START TRANSACTION;

    IF accion = 'I' THEN
        IF pnombres IS NULL OR TRIM(pnombres) = '' THEN
            SET estado = 'ERROR';
            SET mensaje = 'El nombre del autor es obligatorio';
            SET codigo = 0;
        ELSE
            INSERT INTO autor(nombres, nacionalidad)
            VALUES (TRIM(pnombres), IFNULL(pnacionalidad, ''));
            SET estado = 'CORRECTO';
            SET mensaje = 'OPERACION REALIZADA';
            SET codigo = LAST_INSERT_ID();
        END IF;

    ELSEIF accion = 'U' THEN
        IF NOT EXISTS (SELECT 1 FROM autor WHERE id = pid) THEN
            SET estado = 'ERROR';
            SET mensaje = 'El autor no existe';
            SET codigo = 0;
        ELSEIF pnombres IS NULL OR TRIM(pnombres) = '' THEN
            SET estado = 'ERROR';
            SET mensaje = 'El nombre del autor es obligatorio';
            SET codigo = 0;
        ELSE
            UPDATE autor
            SET nombres = TRIM(pnombres), nacionalidad = IFNULL(pnacionalidad, '')
            WHERE id = pid;
            SET estado = 'CORRECTO';
            SET mensaje = 'OPERACION REALIZADA';
            SET codigo = pid;
        END IF;

    ELSEIF accion = 'D' THEN
        IF NOT EXISTS (SELECT 1 FROM autor WHERE id = pid) THEN
            SET estado = 'ERROR';
            SET mensaje = 'El autor no existe';
            SET codigo = 0;
        ELSEIF EXISTS (SELECT 1 FROM libro WHERE autor_id = pid) THEN
            SET estado = 'ERROR';
            SET mensaje = 'El autor tiene libros registrados';
            SET codigo = 0;
        ELSE
            DELETE FROM autor WHERE id = pid;
            SET estado = 'CORRECTO';
            SET mensaje = 'OPERACION REALIZADA';
            SET codigo = pid;
        END IF;

    ELSE
        SET estado = 'ERROR';
        SET mensaje = 'Acción no válida';
        SET codigo = 0;
    END IF;

    IF estado = 'CORRECTO' THEN
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;

    SELECT estado, mensaje, codigo;
END ;;
DELIMITER ;

-- Verificación final: libros con su autor, su categoría y sus préstamos
SELECT l.id, l.titulo, a.nombres AS autor, c.nombre AS categoria, l.disponible
FROM libro l
JOIN autor a ON a.id = l.autor_id
JOIN categoria c ON c.id = l.categoria_id
ORDER BY l.id;

-- Préstamos con lector y libro (Actividad 4)
SELECT p.id, lb.titulo AS libro, le.nombres AS lector, le.dni,
       p.fecha_prestamo, p.fecha_devolucion
FROM prestamo p
JOIN lector le ON le.id = p.lector_id
JOIN libro lb ON lb.id = p.libro_id
ORDER BY p.id;
